package wxpay

type Params map[string]string
